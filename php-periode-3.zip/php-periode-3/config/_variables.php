<?php 
define("DBHOST", "localhost");
define("DBNAME", "school");
define("DBUSER", "root");
define("DBPASS", "");
define("BASEHREF", "http://localhost//php per 3");
define("WEBSITE_NAME", "MAX WEBwinkel");
?>